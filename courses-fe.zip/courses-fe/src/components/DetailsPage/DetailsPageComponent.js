import React from 'react';

const DetailsPage = () => {
  return <div>Details page</div>;
};

export default DetailsPage;