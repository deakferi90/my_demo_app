export const myHeadData = {
    tableHead: ['Alex', 'Feri']
};